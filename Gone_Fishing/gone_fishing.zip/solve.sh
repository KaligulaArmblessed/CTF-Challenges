#!/bin/bash

ln -s /etc/passwd /tmp/fishing
mv plnfwkjmdejpkz test
kill -64 1
